# main.py
from database import init_db, add_pokemon, delete_pokemon, update_pokemon, list_pokemons

def main():
    init_db()
    while True:
        print("\n" + "="*40)
        print("🎮 Добро пожаловать в PokeCatcher!")
        print("="*40)
        print("1. Поймать покемона")
        print("2. Выпустить покемона")
        print("3. Обновить данные покемона")
        print("4. Показать всех покемонов")
        print("5. Выйти")
        print("-"*40)
        
        choice = input("Выбери действие (1-5): ").strip()
        
        if choice == '1':
            name = input("Имя покемона: ").strip()
            ptype = input("Тип покемона (например, Огонь, Вода): ").strip()
            try:
                level = int(input("Уровень (по умолчанию 1): ") or 1)
            except ValueError:
                level = 1
            add_pokemon(name, ptype, level)
            
        elif choice == '2':
            name = input("Имя покемона для выпуска: ").strip()
            delete_pokemon(name)
            
        elif choice == '3':
            name = input("Имя покемона для обновления: ").strip()
            new_type = input("Новый тип (оставь пустым, если не меняешь): ").strip() or None
            new_level = input("Новый уровень (оставь пустым, если не меняешь): ").strip()
            new_level = int(new_level) if new_level.isdigit() else None
            update_pokemon(name, new_type, new_level)
            
        elif choice == '4':
            list_pokemons()
            
        elif choice == '5':
            print("👋 До встречи, тренер!")
            break
            
        else:
            print("❌ Неверный выбор. Попробуй снова.")

if __name__ == "__main__":
    main()