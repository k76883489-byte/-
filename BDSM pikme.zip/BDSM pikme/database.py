# database.py
import sqlite3

def init_db():
    """Инициализация базы данных и создание таблицы"""
    conn = sqlite3.connect('pokemons.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pokemons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            type TEXT NOT NULL,
            level INTEGER DEFAULT 1
        )
    ''')
    
    conn.commit()
    conn.close()

def add_pokemon(name, ptype, level=1):
    """Добавить покемона в базу"""
    try:
        conn = sqlite3.connect('pokemons.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO pokemons (name, type, level) VALUES (?, ?, ?)", (name, ptype, level))
        conn.commit()
        print(f"✅ Покемон {name} пойман!")
    except sqlite3.IntegrityError:
        print(f"❌ Покемон {name} уже пойман!")
    finally:
        conn.close()

def delete_pokemon(name):
    """Удалить покемона из базы"""
    conn = sqlite3.connect('pokemons.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM pokemons WHERE name = ?", (name,))
    if cursor.rowcount > 0:
        print(f"🗑️ Покемон {name} выпущен на волю.")
    else:
        print(f"❌ Покемон {name} не найден.")
    conn.commit()
    conn.close()

def update_pokemon(name, new_type=None, new_level=None):
    """Обновить тип или уровень покемона"""
    conn = sqlite3.connect('pokemons.db')
    cursor = conn.cursor()
    
    updates = []
    params = []
    
    if new_type:
        updates.append("type = ?")
        params.append(new_type)
    if new_level:
        updates.append("level = ?")
        params.append(new_level)
    
    if not updates:
        print("⚠️ Нет данных для обновления.")
        return
    
    params.append(name)
    query = f"UPDATE pokemons SET {', '.join(updates)} WHERE name = ?"
    cursor.execute(query, params)
    
    if cursor.rowcount > 0:
        print(f"🔄 Покемон {name} обновлён!")
    else:
        print(f"❌ Покемон {name} не найден.")
    
    conn.commit()
    conn.close()

def list_pokemons():
    """Показать всех пойманных покемонов"""
    conn = sqlite3.connect('pokemons.db')
    cursor = conn.cursor()
    cursor.execute("SELECT name, type, level FROM pokemons")
    pokemons = cursor.fetchall()
    conn.close()
    
    if pokemons:
        print("\n📦 Твой покедекс:")
        for name, ptype, level in pokemons:
            print(f" - {name} | Тип: {ptype} | Уровень: {level}")
    else:
        print("📭 Покедекс пуст. Иди лови покемонов!")